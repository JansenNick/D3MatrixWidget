//>>built
define("dijit/nls/uk/loading",({loadingState:"Завантаження...",errorState:"Сталася помилка"}));
